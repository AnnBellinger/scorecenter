Ann Bellinger
Assignment 5: ScoreCenter
Due: Thursday, April 18, 2013

Aspects Implemented Correctly:
1. POST API /submit.json that allows any HTML5 game on any web domain to send high scores to application. Cross-origin sharing is enabled

2. GET API /highscores.json that returns the top 10 scores in decending order in a JSON string for any given game

3. /Home root that displays all the scores for all of the games

4. /usersearch that allows user to search a particular name, search returns all scores for that user on a new page

Aspects Implemented Incorrectly:
None I hope :) 

Time Spent: 
~30 hours Heroku/Mongo reserach
~30 hours writing/testing 

Help:
THANK YOU MING FOR HELPING ME!!!